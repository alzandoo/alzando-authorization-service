"""Alzando authorization service."""
